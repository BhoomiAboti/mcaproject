from odoo import http
from openerp import SUPERUSER_ID
import re
 

class gvpdata(http.Controller):
     
     @http.route('/',type="http", auth='public',website=True)
     def home1a_page(self, **kwargs):  

         staffsinfo1 = http.request.env['event.event'].search([])
         return http.request.render('gvpdemo.homepage', {
             'staff_detailss': staffsinfo1
         }) 

     # @http.route('/homepage',type="http", auth='public',website=True)
     # def home1_page(self, **kwargs):
     #      return http.request.render('gvpdemo.homepage')

     @http.route('/home',type="http", auth='public',website=True)
     def home_page(self, **kwargs):        
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:        
               match = re.search(list1, new_url)       
                      

         if match:
               result = match.group()
               msg=result
               visible = True
         else:
               msg="No match"  
               if http.request.env.user.id == SUPERUSER_ID:
                  visible = True 
               else:
                  visible = False         
   
               
         return http.request.render('gvpdemo.home',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         
     # ***************About us***************

     @http.route('/about/history2',type="http", auth='public',website=True)
     def hostory2_page(self, **kwargs):
            partner = http.request.env.user.partner_id             
            user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
            new_url=http.request.httprequest.full_path
            uid= http.request.env.user.id   
            wt = http.request.env[ 'res.users' ]
            id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
            new = wt.browse(id_needed)
            list1 = new.page_url    
            if list1!='':               
               match = re.search('', new_url)
            else:        
               match = re.search(list1, new_url)       
                      

            if match:
               result = match.group()
               msg=result
               visible = True
            else:
               msg="No match"  
               if http.request.env.user.id == SUPERUSER_ID:
                  visible = True 
               else:
                  visible = False         

            return http.request.render('gvpdemo.history2',{'visible': visible,'list1':list1})      
            return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

   
     @http.route('/about/establishment',type="http", auth='public',website=True)
     def establishment_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:        
               
               match = re.search(list1, new_url)   

         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.establishment',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

       
         
        
     @http.route('/about/values1',type="http", auth='public',website=True)
     def values1_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.values1',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

      
       

     @http.route('/about/emblem',type="http", auth='public',website=True)
     def emblem_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.emblem',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

       
     @http.route('/about/song1',type="http", auth='public',website=True)
     def song1_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.song1',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

        
         
    
     @http.route('/about/salientsfeatures',type="http", auth='public',website=True)
     def salients_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.salientsfeatures',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         return http.request.render('gvpdemo.salientsfeatures')
         
     @http.route('/about/objective2',type="http", auth='public',website=True)
     def objective2_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False    
               
         return http.request.render('gvpdemo.objective2',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         

     @http.route('/about/mission',type="http", auth='public',website=True)
     def mission_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.mission',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

        

     @http.route('/about/gvpact',type="http", auth='public',website=True)
     def gvpact_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False     
               
         return http.request.render('gvpdemo.gvpact',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         

     @http.route('/about/uniqueness',type="http", auth='public',website=True)
     def uniqueness_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.uniqueness',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         

     @http.route('/about/vision',type="http", auth='public',website=True)
     def vision_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.vision',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         

     @http.route('/about/structgvp',type="http", auth='public',website=True)
     def structgvp_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.structgvp',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

       



        #*************Administration*********************

     @http.route('/administration/chancellors',type="http", auth='public',website=True)
     def chancellor_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.chancellors',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

        

     @http.route('/administration/vicechancellors',type="http", auth='public',website=True)
     def vicechancellor_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
               
         return http.request.render('gvpdemo.vicechancellors',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

         

     @http.route('/administration/registrar',type="http", auth='public',website=True)
     def registrar_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.registrar',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/administration/gvpmandal',type="http", auth='public',website=True)
     def gvpmandal_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False    
               
         return http.request.render('gvpdemo.gvpmandal',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/administration/adprof',type="http", auth='public',website=True)
     def adprof_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False     
               
         return http.request.render('gvpdemo.adprof',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

    #*****************Academics***************************

     @http.route('/academics/language',type="http", auth='public',website=True)
     def language_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                   
               
         return http.request.render('gvpdemo.language',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         


     @http.route('/academics/social1',type="http", auth='public',website=True)
     def social_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.social1',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/academics/education',type="http", auth='public',website=True)
     def education_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.education',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/academics/managment',type="http", auth='public',website=True)
     def managment_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                   
               
         return http.request.render('gvpdemo.managment',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/academics/hindi',type="http", auth='public',website=True)
     def hindi_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                   
               
         return http.request.render('gvpdemo.hindi',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         


     @http.route('/academics/english',type="http", auth='public',website=True)
     def english_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.english',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/anthropology',type="http", auth='public',website=True)
     def anthropology_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                     
               
         return http.request.render('gvpdemo.anthropology',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/rural',type="http", auth='public',website=True)
     def rural_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.rural',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         
     @http.route('/academics/IASE1',type="http", auth='public',website=True)
     def IASE1_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.IASE1',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/academics/biology',type="http", auth='public',website=True)
     def biology_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.biology',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/hscience',type="http", auth='public',website=True)
     def hscience_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
         return http.request.render('gvpdemo.hscience',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/academics/gandhian',type="http", auth='public',website=True)
     def gandhian_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                    
               
         return http.request.render('gvpdemo.gandhian',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/swork',type="http", auth='public',website=True)
     def swork_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                   
               
         return http.request.render('gvpdemo.swork',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/jsm',type="http", auth='public',website=True)
     def jsm_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.jsm',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/peducation',type="http", auth='public',website=True)
     def peducation_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                     
               
         return http.request.render('gvpdemo.peducation',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/academics/computer',type="http", auth='public',website=True)
     def computer_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
               
         return http.request.render('gvpdemo.computer',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/academics/ruralm',type="http", auth='public',website=True)
     def ruralm_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                    
               
         return http.request.render('gvpdemo.ruralm',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/deptgujarati',type="http", auth='public',website=True)
     def deptgujarati_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
         return http.request.render('gvpdemo.deptgujarati',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/coprogram',type="http", auth='public',website=True)
     def coprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                    
               
         return http.request.render('gvpdemo.coprogram',{'visible': visible})      
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/cs/program',type="http", auth='public',website=True)
     def program_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url)   
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.program',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

     @http.route('/cs/cfac',type="http", auth='public',website=True)
     def cfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
         return http.request.render('gvpdemo.cfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

     @http.route('/cs/cfaculty',type="http", auth='public',website=True)
     def cfaculty_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
         
         return http.request.render('gvpdemo.cfaculty',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/sustaff',type="http", auth='public',website=True)
     def sustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  

         return http.request.render('gvpdemo.sustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

     @http.route('/cs/facilities',type="http", auth='public',website=True)
     def facilites_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
                  
         return http.request.render('gvpdemo.facilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

     @http.route('/cs/research',type="http", auth='public',website=True)
     def research_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.research',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/training',type="http", auth='public',website=True)
     def training_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.training',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/achieve',type="http", auth='public',website=True)
     def achieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.achieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/gallery',type="http", auth='public',website=True)
     def gallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.gallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/collaboration1',type="http", auth='public',website=True)
     def collaboration1_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.collaboration1',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/event1',type="http", auth='public',website=True)
     def event1_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.event1',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/alumni',type="http", auth='public',website=True)
     def alumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.alumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/cs/download',type="http", auth='public',website=True)
     def download_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.download',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})


     @http.route('/submman',type="http", auth='public',website=True)
     def submman_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.submman',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hindip',type="http", auth='public',website=True)
     def hindip_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.hindip',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hindifac',type="http", auth='public',website=True)
     def hindifac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.hindifac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/hindisustaff',type="http", auth='public',website=True)
     def hindisustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.hindisustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        
     @http.route('/hindifacilities',type="http", auth='public',website=True)
     def hindifacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hindifacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hindiresearch',type="http", auth='public',website=True)
     def hindiresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.hindiresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hinditraining',type="http", auth='public',website=True)
     def hinditraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.hinditraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/engprogram',type="http", auth='public',website=True)
     def engprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.engprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/engmenu',type="http", auth='public',website=True)
     def engmenu_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.engmenu',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       
     @http.route('/mca',type="http", auth='public',website=True)
     def mca_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.mca',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/pgdca',type="http", auth='public',website=True)
     def pgdca_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.pgdca',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/he-menu',type="http", auth='public',website=True)
     def hemenu_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.h',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         
     @http.route('/engfac',type="http", auth='public',website=True)
     def engfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.engfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/engresearch',type="http", auth='public',website=True)
     def engresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False 
         return http.request.render('gvpdemo.engresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/engfacilities',type="http", auth='public',website=True)
     def engfacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engfacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/engtraining',type="http", auth='public',website=True)
     def engtraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engtraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/engachieve',type="http", auth='public',website=True)
     def engachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/enggallery',type="http", auth='public',website=True)
     def enggallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.enggallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        


     @http.route('/engcollab',type="http", auth='public',website=True)
     def engcollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engcollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/engevent',type="http", auth='public',website=True)
     def engevent_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engevent',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/engalumni',type="http", auth='public',website=True)
     def engalumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engalumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/engdownload',type="http", auth='public',website=True)
     def engdownload_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.engdownload',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/submdsocial',type="http", auth='public',website=True)
     def submdsocial_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdsocial',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/soprogram',type="http", auth='public',website=True)
     def soprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.soprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/sofac',type="http", auth='public',website=True)
     def sofac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sofac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/submdrural',type="http", auth='public',website=True)
     def submdrural_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdrural',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/ruprogram',type="http", auth='public',website=True)
     def ruprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.ruprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/submdedu',type="http", auth='public',website=True)
     def submdedu_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdedu',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/eduprogram',type="http", auth='public',website=True)
     def eduprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.eduprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/edufac',type="http", auth='public',website=True)
     def edufac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.edufac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/edufacilities',type="http", auth='public',website=True)
     def edufacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.edufacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
    

     @http.route('/eduresearch',type="http", auth='public',website=True)
     def eduresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.eduresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/eduachieve',type="http", auth='public',website=True)
     def eduachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.eduachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/eduachieve',type="http", auth='public',website=True)
     def eduachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.eduachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/rufac',type="http", auth='public',website=True)
     def rufac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.rufac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/rureseach',type="http", auth='public',website=True)
     def ruresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.rureseach',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/edutraining',type="http", auth='public',website=True)
     def edutraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.edutraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/edudownload',type="http", auth='public',website=True)
     def edudownload_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.edudownload',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/bioprogram',type="http", auth='public',website=True)
     def bioprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.bioprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/subbio',type="http", auth='public',website=True)
     def subbio_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.subbio',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/biofac',type="http", auth='public',website=True)
     def biofac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biofac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/biofacilities',type="http", auth='public',website=True)
     def biofacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biofacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/biosustaff',type="http", auth='public',website=True)
     def biosustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biosustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/biotraining',type="http", auth='public',website=True)
     def biotraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biotraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/bioachieve',type="http", auth='public',website=True)
     def bioachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.bioachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/biogallery',type="http", auth='public',website=True)
     def biogallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biogallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/biocollab',type="http", auth='public',website=True)
     def biocollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.biocollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/subhome',type="http", auth='public',website=True)
     def subhome_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.subhome',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/hoprogramme',type="http", auth='public',website=True)
     def hoprogramme_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         match = re.search(list1, new_url)
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            visible = False 
         return http.request.render('gvpdemo.hoprogramme',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/staffbiodata',type="http", auth='public',website=True)
     def staffbiodata_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.staffbiodata',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/gvpstaff',type="http", auth='public',website=True)
     def gvpstaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.gvpstaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})

     @http.route('/hosustaff',type="http", auth='public',website=True)
     def hosustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hosustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hofacilities',type="http", auth='public',website=True)
     def hofacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hofacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/hotraining',type="http", auth='public',website=True)
     def hotraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hotraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/horesearch',type="http", auth='public',website=True)
     def horesearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.horesearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/hoachieve',type="http", auth='public',website=True)
     def hoachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hoachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/hogallery',type="http", auth='public',website=True)
     def hogallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hogallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        


     @http.route('/hocollab',type="http", auth='public',website=True)
     def hocollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hocollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/hoalumni',type="http", auth='public',website=True)
     def hoalumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hoalumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/hodownload',type="http", auth='public',website=True)
     def hodownload_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hodownload',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         
     @http.route('/subgandhi',type="http", auth='public',website=True)
     def subgandhi_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.subgandhi',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/gandhiprogram',type="http", auth='public',website=True)
     def gandhiprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhiprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/gandhifac',type="http", auth='public',website=True)
     def gandhifac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhifac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/gandhiresearch',type="http", auth='public',website=True)
     def gandhiresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhiresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/gandhifacilities',type="http", auth='public',website=True)
     def gandhifacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhifacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/gandhicollab',type="http", auth='public',website=True)
     def gandhicollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhicollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/gandhievents',type="http", auth='public',website=True)
     def gandhievents_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhievents',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/gandhialumni',type="http", auth='public',website=True)
     def gandhialumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gandhialumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/facilities',type="http", auth='public',website=True)
     def facilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.facilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
    

     @http.route('/submguj',type="http", auth='public',website=True)
     def submguj_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sub',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        


     @http.route('/gvpdepartment',type="http", auth='public',website=True)
     def gvpdepartment_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.gvpdepartment',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     


     @http.route('/gujfacilities',type="http", auth='public',website=True)
     def gujfacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujfacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/gujtraining',type="http", auth='public',website=True)
     def gujtraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujtraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/gujachieve',type="http", auth='public',website=True)
     def gujachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         return 

     @http.route('/gujgallery',type="http", auth='public',website=True)
     def gujgallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujgallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
     @http.route('/gujcollab',type="http", auth='public',website=True)
     def gujcollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujcollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/gujevent',type="http", auth='public',website=True)
     def gujevent_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujevent',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/gujcollab',type="http", auth='public',website=True)
     def gujcollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.gujcollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/submdso',type="http", auth='public',website=True)
     def submdso_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdso',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodprogram',type="http", auth='public',website=True)
     def sodprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/sodfac',type="http", auth='public',website=True)
     def sodfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodsustaff',type="http", auth='public',website=True)
     def sodsustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodsustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodfacilities',type="http", auth='public',website=True)
     def sodfacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodfacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/sodresearch',type="http", auth='public',website=True)
     def sodresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/sodext',type="http", auth='public',website=True)
     def sodext_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodext',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodtraining',type="http", auth='public',website=True)
     def sodtraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodtraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     # @http.route('/sodachieve',type="http", auth='public',website=True)
     # def sodachieve_page(self, **kwargs):
     #     return http.request.render('gvpdemo.sodachieve')

     @http.route('/sodgallery',type="http", auth='public',website=True)
     def sodgallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodgallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/sodmou',type="http", auth='public',website=True)
     def sodmou_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodmou',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodcollab',type="http", auth='public',website=True)
     def sodcollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodcollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/sodevent',type="http", auth='public',website=True)
     def sodevent_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodevent',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/sodalumni',type="http", auth='public',website=True)
     def sodalumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sodalumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/soddownload',type="http", auth='public',website=True)
     def soddownload_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.soddownload',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/submjsm',type="http", auth='public',website=True)
     def submjsm_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submjsm',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/jsmprogram',type="http", auth='public',website=True)
     def jsmprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/jsmfac',type="http", auth='public',website=True)
     def jsmfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/jsmsustaff',type="http", auth='public',website=True)
     def jsmsustaff_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.jsmsustaff',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/jsmfacilities',type="http", auth='public',website=True)
     def jsmfacilities_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmfacilities',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/jsmresearch',type="http", auth='public',website=True)
     def jsmresearch_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmresearch',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/jsmtraining',type="http", auth='public',website=True)
     def jsmtraining_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False   
         return http.request.render('gvpdemo.jsmtraining',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
      

     @http.route('/jsmachieve',type="http", auth='public',website=True)
     def jsmachieve_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmachieve',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/jsmgallery',type="http", auth='public',website=True)
     def jsmgallery_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmgallery',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/jsmcollab',type="http", auth='public',website=True)
     def jsmcollab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmcollab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        
     @http.route('/jsmevent',type="http", auth='public',website=True)
     def jsmevent_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmevent',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/jsmalumni',type="http", auth='public',website=True)
     def jsmalumni_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmalumni',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
 

     @http.route('/jsmdownload',type="http", auth='public',website=True)
     def jsmdownload_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.jsmdownload',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/submlib',type="http", auth='public',website=True)
     def submlib_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submlib',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/deptlib',type="http", auth='public',website=True)
     def deptlib_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.deptlib',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/libprogram',type="http", auth='public',website=True)
     def libprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.libprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/libfac',type="http", auth='public',website=True)
     def libfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.libfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
     @http.route('/submpedu',type="http", auth='public',website=True)
     def submpedu_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submpedu',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
     @http.route('/peduprogram',type="http", auth='public',website=True)
     def peduprogram_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.peduprogram',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         
         



    #*****************Centres***************************

     @http.route('/centres/bhartiya',type="http", auth='public',website=True)
     def bhartiya_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.bhartiya',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/centres/hindibhasha',type="http", auth='public',website=True)
     def hindibhasha_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hindibhasha',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/centres/usic',type="http", auth='public',website=True)
     def usic_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.usic',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/centres/npcentre',type="http", auth='public',website=True)
     def npcentre_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.npcentre',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
        

     @http.route('/centres/submkvk',type="http", auth='public',website=True)
     def submkvk_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submkvk',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/krikendra',type="http", auth='public',website=True)
     def krikendra_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.krikendra',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
       

     @http.route('/kridethali',type="http", auth='public',website=True)
     def kridethali_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.kridethali',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     
         

     @http.route('/kriambheti',type="http", auth='public',website=True)
     def kriambheti_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.kriambheti',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

    #*****************Facilities***************************

     @http.route('/facilities/arogya',type="http", auth='public',website=True)
     def arogya_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.arogya',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/facilities/library',type="http", auth='public',website=True)
     def library_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.library',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       
     @http.route('/facilities/sports',type="http", auth='public',website=True)
     def sports_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.sports',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/facilities/hostel',type="http", auth='public',website=True)
     def hostel_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.hostel',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/auditorium',type="http", auth='public',website=True)
     def audotorium_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.auditorium',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

    #***************sub menu***************

     @http.route('/subm',type="http", auth='public',website=True)
     def sub_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.subm',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
     

     @http.route('/submab',type="http", auth='public',website=True)
     def subab_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/submadd',type="http", auth='public',website=True)
     def subadd_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submadd',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/submlang',type="http", auth='public',website=True)
     def submlang_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submlang',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/submsocial',type="http", auth='public',website=True)
     def submsocial_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submsocial',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/submmanag',type="http", auth='public',website=True)
     def submmanag_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submmanag',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
         

     @http.route('/submdhindi',type="http", auth='public',website=True)
     def submdhindi_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdhindi',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/submdcomp',type="http", auth='public',website=True)
     def submdcomp_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdcomp',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
        

     @http.route('/submdeng',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submdeng',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     @http.route('/submcentres',type="http", auth='public',website=True)
     def submcentres_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submcentres',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
      

     @http.route('/submfac',type="http", auth='public',website=True)
     def submfac_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.submfac',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       


     @http.route('/estab',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         partner = http.request.env.user.partner_id       
         user_prof_p = http.request.env['res.users'].search([('partner_id', '=', partner.id)])
         new_url=http.request.httprequest.full_path
         uid= http.request.env.user.id   
         wt = http.request.env[ 'res.users' ]
         id_needed = wt.search([ ('partner_id', '=', partner.id) ]).id
         new = wt.browse(id_needed)
         list1 = new.page_url
       
         if list1!='':               
               match = re.search('', new_url)
         else:                       
               match = re.search(list1, new_url) 
         if match:
            result = match.group()
            msg=result
            visible = True
         else:
            msg="No match"  
            if http.request.env.user.id == SUPERUSER_ID:
               visible = True 
            else:
               visible = False  
         return http.request.render('gvpdemo.estab',{'visible': visible})
         return http.request.render('gvpdemo.my_user_navbar',{'visible': visible})
       

     











