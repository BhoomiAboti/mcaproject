# -*- coding: utf-8 -*-

from . import models
from . import education
from . import experience
from . import res_partner
from . import skill