# -*- coding: utf-8 -*-

import re
from odoo import http
from odoo.http import request


class ContactControllerEdu(http.Controller):
    
    @http.route('/my/list/education', type='http', auth='user', website=True)
    def list_education(self, **kwargs):
        partner = request.env.user.partner_id
        return request.render('gvp.education_list', {'educations': partner.education_ids, 'partner': partner})

    @http.route('/my/submit/educataion', type='http', auth='user')
    def submit_educations(self, **kwargs):
        educations = kwargs.get('my_education')
        if educations:
            educations = [int(educations) for skill in educations.split(',')]
            request.env.user.partner_id.write({'education_ids': educations})
        else:
            request.env.user.partner_id.write({'education_ids': False})
        return request.redirect('/my')

    @http.route('/my/delete/education/<model("education"):education>', type='http', auth='user', website=True)
    def delete_education(self, education, **kwargs):
        education.unlink()
        return request.redirect('/my/list/education')