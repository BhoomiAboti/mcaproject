from odoo import http

# class department(http.Controller):
# 	@http.route('/staff/', type="http",auth='public', website=True)
#     def index(self, **kw):
#         staffsinfo = http.request.env['gvp.biodata']
#     return http.request.render('gvpdemo.gvpdept', {
#             'staff_details': staffsinfo.search([])
class department(http.Controller):
    @http.route('/staff/', type="http",auth='public', website=True)
    def index(self, **kw):
         staffsinfo = http.request.env['gvp.biodata']
         return http.request.render('gvpdemo.gvpdept', {'staff_details': staffsinfo.search([])})