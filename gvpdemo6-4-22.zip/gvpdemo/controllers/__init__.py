from . import controllers
from . import biodata
from . import department
from . import educations
from . import portal
from . import main
