from odoo import http

class staffdata(http.Controller):

    @http.route('/staff/', type="http",auth='public', website=True)
    def index(self, **kw):
         staffsinfo = http.request.env['gvp.biodata']
         return http.request.render('gvpdemo.gvpstaff', {
             'staff_details': staffsinfo.search([])
         })
    @http.route('/staff_view/<int:stf_id>/<string:status>', type="http",auth='public',website=True)
    def staff_data(self, stf_id,status,**kwargs):
         staffsinfo1 = http.request.env['gvp.biodata'].search([('id','=',stf_id)])
         return http.request.render('gvpdemo.staffbiodata', {
             'staff_detailss': staffsinfo1
         })

    