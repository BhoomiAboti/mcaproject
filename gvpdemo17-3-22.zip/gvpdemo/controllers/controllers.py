from odoo import http

 

class gvpdata(http.Controller):

     @http.route('/',type="http", auth='public',website=True)
     def home_page(self, **kwargs):
         return http.request.render('gvpdemo.home')

     @http.route('/home',type="http", auth='public',website=True)
     def home_page(self, **kwargs):
         return http.request.render('gvpdemo.home')
         
     # ***************About us***************

     @http.route('/about/history2',type="http", auth='public',website=True)
     def hostory2_page(self, **kwargs):
         return http.request.render('gvpdemo.history2')


     @http.route('/about/establishment',type="http", auth='public',website=True)
     def establishment_page(self, **kwargs):
         return http.request.render('gvpdemo.establishment')
         
        
     @http.route('/about/values1',type="http", auth='public',website=True)
     def values1_page(self, **kwargs):
         return http.request.render('gvpdemo.values1')
         

     @http.route('/about/emblem',type="http", auth='public',website=True)
     def emblem_page(self, **kwargs):
         return http.request.render('gvpdemo.emblem')

     @http.route('/about/song1',type="http", auth='public',website=True)
     def song1_page(self, **kwargs):
         return http.request.render('gvpdemo.song1')
         
    
     @http.route('/about/salientsfeatures',type="http", auth='public',website=True)
     def salients_page(self, **kwargs):
         return http.request.render('gvpdemo.salientsfeatures')
         
     @http.route('/about/objective2',type="http", auth='public',website=True)
     def objective2_page(self, **kwargs):
         return http.request.render('gvpdemo.objective2')

     @http.route('/about/mission',type="http", auth='public',website=True)
     def mission_page(self, **kwargs):
         return http.request.render('gvpdemo.mission')

     @http.route('/about/gvpact',type="http", auth='public',website=True)
     def gvpact_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpact')

     @http.route('/about/uniqueness',type="http", auth='public',website=True)
     def uniqueness_page(self, **kwargs):
         return http.request.render('gvpdemo.uniqueness')

     @http.route('/about/vision',type="http", auth='public',website=True)
     def vision_page(self, **kwargs):
         return http.request.render('gvpdemo.vision')

     @http.route('/about/structgvp',type="http", auth='public',website=True)
     def structgvp_page(self, **kwargs):
         return http.request.render('gvpdemo.structgvp')



        #*************Administration*********************

     @http.route('/administration/chancellors',type="http", auth='public',website=True)
     def chancellor_page(self, **kwargs):
         return http.request.render('gvpdemo.chancellors')

     @http.route('/administration/vicechancellors',type="http", auth='public',website=True)
     def vicechancellor_page(self, **kwargs):
         return http.request.render('gvpdemo.vicechancellors')

     @http.route('/administration/registrar',type="http", auth='public',website=True)
     def registrar_page(self, **kwargs):
         return http.request.render('gvpdemo.registrar')

     @http.route('/administration/gvpmandal',type="http", auth='public',website=True)
     def gvpmandal_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpmandal')

     @http.route('/administration/adprof',type="http", auth='public',website=True)
     def adprof_page(self, **kwargs):
         return http.request.render('gvpdemo.adprof')

    #*****************Academics***************************

     @http.route('/academics/language',type="http", auth='public',website=True)
     def language_page(self, **kwargs):
         return http.request.render('gvpdemo.language')


     @http.route('/academics/social1',type="http", auth='public',website=True)
     def social_page(self, **kwargs):
         return http.request.render('gvpdemo.social1')

     @http.route('/academics/education',type="http", auth='public',website=True)
     def education_page(self, **kwargs):
         return http.request.render('gvpdemo.education')

     @http.route('/academics/managment',type="http", auth='public',website=True)
     def managment_page(self, **kwargs):
         return http.request.render('gvpdemo.managment')

     @http.route('/academics/hindi',type="http", auth='public',website=True)
     def hindi_page(self, **kwargs):
         return http.request.render('gvpdemo.hindi')


     @http.route('/academics/english',type="http", auth='public',website=True)
     def english_page(self, **kwargs):
         return http.request.render('gvpdemo.english')

     @http.route('/academics/anthropology',type="http", auth='public',website=True)
     def anthropology_page(self, **kwargs):
         return http.request.render('gvpdemo.anthropology')

     @http.route('/academics/rural',type="http", auth='public',website=True)
     def rural_page(self, **kwargs):
         return http.request.render('gvpdemo.rural')

     @http.route('/academics/IASE1',type="http", auth='public',website=True)
     def IASE1_page(self, **kwargs):
         return http.request.render('gvpdemo.IASE1')

     @http.route('/academics/biology',type="http", auth='public',website=True)
     def biology_page(self, **kwargs):
         return http.request.render('gvpdemo.biology')

     @http.route('/academics/hscience',type="http", auth='public',website=True)
     def hscience_page(self, **kwargs):
         return http.request.render('gvpdemo.hscience')

     @http.route('/academics/gandhian',type="http", auth='public',website=True)
     def gandhian_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhian')

     @http.route('/academics/swork',type="http", auth='public',website=True)
     def swork_page(self, **kwargs):
         return http.request.render('gvpdemo.swork')

     @http.route('/academics/jsm',type="http", auth='public',website=True)
     def jsm_page(self, **kwargs):
         return http.request.render('gvpdemo.jsm')

     @http.route('/academics/peducation',type="http", auth='public',website=True)
     def peducation_page(self, **kwargs):
         return http.request.render('gvpdemo.peducation')

     @http.route('/academics/computer',type="http", auth='public',website=True)
     def computer_page(self, **kwargs):
         return http.request.render('gvpdemo.computer')

     @http.route('/academics/ruralm',type="http", auth='public',website=True)
     def ruralm_page(self, **kwargs):
         return http.request.render('gvpdemo.ruralm')

     @http.route('/deptgujarati',type="http", auth='public',website=True)
     def deptgujarati_page(self, **kwargs):
         return http.request.render('gvpdemo.deptgujarati')

     @http.route('/coprogram',type="http", auth='public',website=True)
     def coprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.coprogram')

     @http.route('/program',type="http", auth='public',website=True)
     def program_page(self, **kwargs):
         return http.request.render('gvpdemo.program')

     @http.route('/cfac',type="http", auth='public',website=True)
     def cfac_page(self, **kwargs):
         return http.request.render('gvpdemo.cfac')

     @http.route('/cfaculty',type="http", auth='public',website=True)
     def cfaculty_page(self, **kwargs):
         return http.request.render('gvpdemo.cfaculty')

     @http.route('/sustaff',type="http", auth='public',website=True)
     def sustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.sustaff')

     @http.route('/facilities',type="http", auth='public',website=True)
     def facilites_page(self, **kwargs):
         return http.request.render('gvpdemo.facilities')

     @http.route('/research',type="http", auth='public',website=True)
     def research_page(self, **kwargs):
         return http.request.render('gvpdemo.research')

     @http.route('/training',type="http", auth='public',website=True)
     def training_page(self, **kwargs):
         return http.request.render('gvpdemo.training')

     @http.route('/achieve',type="http", auth='public',website=True)
     def achieve_page(self, **kwargs):
         return http.request.render('gvpdemo.achieve')

     @http.route('/gallery',type="http", auth='public',website=True)
     def gallery_page(self, **kwargs):
         return http.request.render('gvpdemo.gallery')

     @http.route('/collaboration1',type="http", auth='public',website=True)
     def collaboration1_page(self, **kwargs):
         return http.request.render('gvpdemo.collaboration1')

     @http.route('/event1',type="http", auth='public',website=True)
     def event1_page(self, **kwargs):
         return http.request.render('gvpdemo.event1')

     @http.route('/alumni',type="http", auth='public',website=True)
     def alumni_page(self, **kwargs):
         return http.request.render('gvpdemo.alumni')

     @http.route('/download',type="http", auth='public',website=True)
     def download_page(self, **kwargs):
         return http.request.render('gvpdemo.download')

     @http.route('/submman',type="http", auth='public',website=True)
     def submman_page(self, **kwargs):
         return http.request.render('gvpdemo.submman')

     @http.route('/hindip',type="http", auth='public',website=True)
     def hindip_page(self, **kwargs):
         return http.request.render('gvpdemo.hindip')

     @http.route('/hindifac',type="http", auth='public',website=True)
     def hindifac_page(self, **kwargs):
         return http.request.render('gvpdemo.hindifac')

     @http.route('/hindisustaff',type="http", auth='public',website=True)
     def hindisustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.hindisustaff')

     @http.route('/hindifacilities',type="http", auth='public',website=True)
     def hindifacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.hindifacilities')

     @http.route('/hindiresearch',type="http", auth='public',website=True)
     def hindiresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.hindiresearch')

     @http.route('/hinditraining',type="http", auth='public',website=True)
     def hinditraining_page(self, **kwargs):
         return http.request.render('gvpdemo.hinditraining')

     @http.route('/engprogram',type="http", auth='public',website=True)
     def engprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.engprogram')

     @http.route('/engmenu',type="http", auth='public',website=True)
     def engmenu_page(self, **kwargs):
         return http.request.render('gvpdemo.engmenu')

     @http.route('/mca',type="http", auth='public',website=True)
     def mca_page(self, **kwargs):
         return http.request.render('gvpdemo.mca')

     @http.route('/pgdca',type="http", auth='public',website=True)
     def pgdca_page(self, **kwargs):
         return http.request.render('gvpdemo.pgdca')

     @http.route('/he-menu',type="http", auth='public',website=True)
     def hemenu_page(self, **kwargs):
         return http.request.render('gvpdemo.h')

     @http.route('/engfac',type="http", auth='public',website=True)
     def engfac_page(self, **kwargs):
         return http.request.render('gvpdemo.engfac')

     @http.route('/engresearch',type="http", auth='public',website=True)
     def engresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.engresearch')

     @http.route('/engfacilities',type="http", auth='public',website=True)
     def engfacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.engfacilities')

     @http.route('/engtraining',type="http", auth='public',website=True)
     def engtraining_page(self, **kwargs):
         return http.request.render('gvpdemo.engtraining')

     @http.route('/engachieve',type="http", auth='public',website=True)
     def engachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.engachieve')

     @http.route('/enggallery',type="http", auth='public',website=True)
     def enggallery_page(self, **kwargs):
         return http.request.render('gvpdemo.enggallery')


     @http.route('/engcollab',type="http", auth='public',website=True)
     def engcollab_page(self, **kwargs):
         return http.request.render('gvpdemo.engcollab')

     @http.route('/engevent',type="http", auth='public',website=True)
     def engevent_page(self, **kwargs):
         return http.request.render('gvpdemo.engevent')

     @http.route('/engalumni',type="http", auth='public',website=True)
     def engalumni_page(self, **kwargs):
         return http.request.render('gvpdemo.engalumni')

     @http.route('/engdownload',type="http", auth='public',website=True)
     def engdownload_page(self, **kwargs):
         return http.request.render('gvpdemo.engdownload')

     @http.route('/submdsocial',type="http", auth='public',website=True)
     def submdsocial_page(self, **kwargs):
         return http.request.render('gvpdemo.submdsocial')

     @http.route('/soprogram',type="http", auth='public',website=True)
     def soprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.soprogram')

     @http.route('/sofac',type="http", auth='public',website=True)
     def sofac_page(self, **kwargs):
         return http.request.render('gvpdemo.sofac')

     @http.route('/submdrural',type="http", auth='public',website=True)
     def submdrural_page(self, **kwargs):
         return http.request.render('gvpdemo.submdrural')

     @http.route('/ruprogram',type="http", auth='public',website=True)
     def ruprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.ruprogram')

     @http.route('/submdedu',type="http", auth='public',website=True)
     def submdedu_page(self, **kwargs):
         return http.request.render('gvpdemo.submdedu')

     @http.route('/eduprogram',type="http", auth='public',website=True)
     def eduprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.eduprogram')

     @http.route('/edufac',type="http", auth='public',website=True)
     def edufac_page(self, **kwargs):
         return http.request.render('gvpdemo.edufac')

     @http.route('/edufacilities',type="http", auth='public',website=True)
     def edufacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.edufacilities')

     @http.route('/eduresearch',type="http", auth='public',website=True)
     def eduresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.eduresearch')

     @http.route('/eduachieve',type="http", auth='public',website=True)
     def eduachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.eduachieve')

     @http.route('/eduachieve',type="http", auth='public',website=True)
     def eduachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.eduachieve')

     @http.route('/rufac',type="http", auth='public',website=True)
     def rufac_page(self, **kwargs):
         return http.request.render('gvpdemo.rufac')

     @http.route('/rureseach',type="http", auth='public',website=True)
     def ruresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.rureseach')

     @http.route('/edutraining',type="http", auth='public',website=True)
     def edutraining_page(self, **kwargs):
         return http.request.render('gvpdemo.edutraining')

     @http.route('/edudownload',type="http", auth='public',website=True)
     def edudownload_page(self, **kwargs):
         return http.request.render('gvpdemo.edudownload')

     @http.route('/bioprogram',type="http", auth='public',website=True)
     def bioprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.bioprogram')

     @http.route('/subbio',type="http", auth='public',website=True)
     def subbio_page(self, **kwargs):
         return http.request.render('gvpdemo.subbio')

     @http.route('/biofac',type="http", auth='public',website=True)
     def biofac_page(self, **kwargs):
         return http.request.render('gvpdemo.biofac')

     @http.route('/biofacilities',type="http", auth='public',website=True)
     def biofacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.biofacilities')

     @http.route('/biosustaff',type="http", auth='public',website=True)
     def biosustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.biosustaff')

     @http.route('/biotraining',type="http", auth='public',website=True)
     def biotraining_page(self, **kwargs):
         return http.request.render('gvpdemo.biotraining')

     @http.route('/bioachieve',type="http", auth='public',website=True)
     def bioachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.bioachieve')

     @http.route('/biogallery',type="http", auth='public',website=True)
     def biogallery_page(self, **kwargs):
         return http.request.render('gvpdemo.biogallery')

     @http.route('/biocollab',type="http", auth='public',website=True)
     def biocollab_page(self, **kwargs):
         return http.request.render('gvpdemo.biocollab')

     @http.route('/subhome',type="http", auth='public',website=True)
     def subhome_page(self, **kwargs):
         return http.request.render('gvpdemo.subhome')

     @http.route('/hoprogramme',type="http", auth='public',website=True)
     def hoprogramme_page(self, **kwargs):
         return http.request.render('gvpdemo.hoprogramme')

     @http.route('/staffbiodata',type="http", auth='public',website=True)
     def staffbiodata_page(self, **kwargs):
         return http.request.render('gvpdemo.staffbiodata')

     @http.route('/gvpstaff',type="http", auth='public',website=True)
     def gvpstaff_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpstaff')

     @http.route('/hosustaff',type="http", auth='public',website=True)
     def hosustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.hosustaff')

     @http.route('/hofacilities',type="http", auth='public',website=True)
     def hofacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.hofacilities')

     @http.route('/hotraining',type="http", auth='public',website=True)
     def hotraining_page(self, **kwargs):
         return http.request.render('gvpdemo.hotraining')

     @http.route('/horesearch',type="http", auth='public',website=True)
     def horesearch_page(self, **kwargs):
         return http.request.render('gvpdemo.horesearch')

     @http.route('/hoachieve',type="http", auth='public',website=True)
     def hoachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.hoachieve')

     @http.route('/hogallery',type="http", auth='public',website=True)
     def hogallery_page(self, **kwargs):
         return http.request.render('gvpdemo.hogallery')


     @http.route('/hocollab',type="http", auth='public',website=True)
     def hocollab_page(self, **kwargs):
         return http.request.render('gvpdemo.hocollab')

     @http.route('/hoalumni',type="http", auth='public',website=True)
     def hoalumni_page(self, **kwargs):
         return http.request.render('gvpdemo.hoalumni')

     @http.route('/hodownload',type="http", auth='public',website=True)
     def hodownload_page(self, **kwargs):
         return http.request.render('gvpdemo.hodownload')

     @http.route('/subgandhi',type="http", auth='public',website=True)
     def subgandhi_page(self, **kwargs):
         return http.request.render('gvpdemo.subgandhi')

     @http.route('/gandhiprogram',type="http", auth='public',website=True)
     def gandhiprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhiprogram')

     @http.route('/gandhifac',type="http", auth='public',website=True)
     def gandhifac_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhifac')

     @http.route('/gandhiresearch',type="http", auth='public',website=True)
     def gandhiresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhiresearch')

     @http.route('/gandhifacilities',type="http", auth='public',website=True)
     def gandhifacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhifacilities')

     @http.route('/gandhicollab',type="http", auth='public',website=True)
     def gandhicollab_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhicollab')

     @http.route('/gandhievents',type="http", auth='public',website=True)
     def gandhievents_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhievents')

     @http.route('/gandhialumni',type="http", auth='public',website=True)
     def gandhialumni_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhialumni')

     @http.route('/facilities',type="http", auth='public',website=True)
     def facilities_page(self, **kwargs):
         return http.request.render('gvpdemo.facilities')

     @http.route('/submguj',type="http", auth='public',website=True)
     def submguj_page(self, **kwargs):
         return http.request.render('gvpdemo.sub')


     @http.route('/gvpdepartment',type="http", auth='public',website=True)
     def gvpdepartment_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpdepartment')

     @http.route('/gujfacilities',type="http", auth='public',website=True)
     def gujfacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.gujfacilities')

     @http.route('/gujtraining',type="http", auth='public',website=True)
     def gujtraining_page(self, **kwargs):
         return http.request.render('gvpdemo.gujtraining')

     @http.route('/gujachieve',type="http", auth='public',website=True)
     def gujachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.gujachieve')

     @http.route('/gujgallery',type="http", auth='public',website=True)
     def gujgallery_page(self, **kwargs):
         return http.request.render('gvpdemo.gujgallery')

     @http.route('/gujcollab',type="http", auth='public',website=True)
     def gujcollab_page(self, **kwargs):
         return http.request.render('gvpdemo.gujcollab')

     @http.route('/gujevent',type="http", auth='public',website=True)
     def gujevent_page(self, **kwargs):
         return http.request.render('gvpdemo.gujevent')

     @http.route('/gujcollab',type="http", auth='public',website=True)
     def gujcollab_page(self, **kwargs):
         return http.request.render('gvpdemo.gujcollab')

     @http.route('/submdso',type="http", auth='public',website=True)
     def submdso_page(self, **kwargs):
         return http.request.render('gvpdemo.submdso')

     @http.route('/sodprogram',type="http", auth='public',website=True)
     def sodprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.sodprogram')

     @http.route('/sodfac',type="http", auth='public',website=True)
     def sodfac_page(self, **kwargs):
         return http.request.render('gvpdemo.sodfac')

     @http.route('/sodsustaff',type="http", auth='public',website=True)
     def sodsustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.sodsustaff')

     @http.route('/sodfacilities',type="http", auth='public',website=True)
     def sodfacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.sodfacilities')

     @http.route('/sodresearch',type="http", auth='public',website=True)
     def sodresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.sodresearch')

     @http.route('/sodext',type="http", auth='public',website=True)
     def sodext_page(self, **kwargs):
         return http.request.render('gvpdemo.sodext')

     @http.route('/sodtraining',type="http", auth='public',website=True)
     def sodtraining_page(self, **kwargs):
         return http.request.render('gvpdemo.sodtraining')

     # @http.route('/sodachieve',type="http", auth='public',website=True)
     # def sodachieve_page(self, **kwargs):
     #     return http.request.render('gvpdemo.sodachieve')

     @http.route('/sodgallery',type="http", auth='public',website=True)
     def sodgallery_page(self, **kwargs):
         return http.request.render('gvpdemo.sodgallery')

     @http.route('/sodmou',type="http", auth='public',website=True)
     def sodmou_page(self, **kwargs):
         return http.request.render('gvpdemo.sodmou')

     @http.route('/sodcollab',type="http", auth='public',website=True)
     def sodcollab_page(self, **kwargs):
         return http.request.render('gvpdemo.sodcollab')

     @http.route('/sodevent',type="http", auth='public',website=True)
     def sodevent_page(self, **kwargs):
         return http.request.render('gvpdemo.sodevent')

     @http.route('/sodalumni',type="http", auth='public',website=True)
     def sodalumni_page(self, **kwargs):
         return http.request.render('gvpdemo.sodalumni')

     @http.route('/soddownload',type="http", auth='public',website=True)
     def soddownload_page(self, **kwargs):
         return http.request.render('gvpdemo.soddownload')

     @http.route('/submjsm',type="http", auth='public',website=True)
     def submjsm_page(self, **kwargs):
         return http.request.render('gvpdemo.submjsm')

     @http.route('/jsmprogram',type="http", auth='public',website=True)
     def jsmprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmprogram')

     @http.route('/jsmfac',type="http", auth='public',website=True)
     def jsmfac_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmfac')

     @http.route('/jsmsustaff',type="http", auth='public',website=True)
     def jsmsustaff_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmsustaff')

     @http.route('/jsmfacilities',type="http", auth='public',website=True)
     def jsmfacilities_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmfacilities')

     @http.route('/jsmresearch',type="http", auth='public',website=True)
     def jsmresearch_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmresearch')

     @http.route('/jsmtraining',type="http", auth='public',website=True)
     def jsmtraining_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmtraining')

     @http.route('/jsmachieve',type="http", auth='public',website=True)
     def jsmachieve_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmachieve')

     @http.route('/jsmgallery',type="http", auth='public',website=True)
     def jsmgallery_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmgallery')

     @http.route('/jsmcollab',type="http", auth='public',website=True)
     def jsmcollab_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmcollab')

     @http.route('/jsmevent',type="http", auth='public',website=True)
     def jsmevent_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmevent')

     @http.route('/jsmalumni',type="http", auth='public',website=True)
     def jsmalumni_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmalumni')

     @http.route('/jsmdownload',type="http", auth='public',website=True)
     def jsmdownload_page(self, **kwargs):
         return http.request.render('gvpdemo.jsmdownload')































     





    #*****************Centres***************************

     @http.route('/centres/bhartiya',type="http", auth='public',website=True)
     def bhartiya_page(self, **kwargs):
         return http.request.render('gvpdemo.bhartiya')

     @http.route('/centres/hindibhasha',type="http", auth='public',website=True)
     def hindibhasha_page(self, **kwargs):
         return http.request.render('gvpdemo.hindibhasha')


    #*****************Facilities***************************

     @http.route('/facilities/arogya',type="http", auth='public',website=True)
     def arogya_page(self, **kwargs):
         return http.request.render('gvpdemo.arogya')

     @http.route('/facilities/library',type="http", auth='public',website=True)
     def library_page(self, **kwargs):
         return http.request.render('gvpdemo.library')

     @http.route('/facilities/sports',type="http", auth='public',website=True)
     def sports_page(self, **kwargs):
         return http.request.render('gvpdemo.sports')

     @http.route('/facilities/hostel',type="http", auth='public',website=True)
     def hostel_page(self, **kwargs):
         return http.request.render('gvpdemo.hostel')

     @http.route('/auditorium',type="http", auth='public',website=True)
     def audotorium_page(self, **kwargs):
         return http.request.render('gvpdemo.auditorium')

    #***************sub menu***************

     @http.route('/subm',type="http", auth='public',website=True)
     def sub_page(self, **kwargs):
         return http.request.render('gvpdemo.subm')

     @http.route('/submab',type="http", auth='public',website=True)
     def subab_page(self, **kwargs):
         return http.request.render('gvpdemo.submab')

     @http.route('/submadd',type="http", auth='public',website=True)
     def subadd_page(self, **kwargs):
         return http.request.render('gvpdemo.submadd')

     @http.route('/submlang',type="http", auth='public',website=True)
     def submlang_page(self, **kwargs):
         return http.request.render('gvpdemo.submlang')

     @http.route('/submsocial',type="http", auth='public',website=True)
     def submsocial_page(self, **kwargs):
         return http.request.render('gvpdemo.submsocial')

     @http.route('/submmanag',type="http", auth='public',website=True)
     def submmanag_page(self, **kwargs):
         return http.request.render('gvpdemo.submmanag')

     @http.route('/submdhindi',type="http", auth='public',website=True)
     def submdhindi_page(self, **kwargs):
         return http.request.render('gvpdemo.submdhindi')

     @http.route('/submdcomp',type="http", auth='public',website=True)
     def submdcomp_page(self, **kwargs):
         return http.request.render('gvpdemo.submdcomp')

     @http.route('/submdeng',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         return http.request.render('gvpdemo.submdeng')

     @http.route('/submcentres',type="http", auth='public',website=True)
     def submcentres_page(self, **kwargs):
         return http.request.render('gvpdemo.submcentres')

     @http.route('/submfac',type="http", auth='public',website=True)
     def submfac_page(self, **kwargs):
         return http.request.render('gvpdemo.submfac')


     @http.route('/estab',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         return http.request.render('gvpdemo.estab')











