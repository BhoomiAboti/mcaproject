# -*- coding: utf-8 -*-

from odoo import models, fields, api


class biodata(models.Model):
    _name = 'gvp.biodata'
    _description = 'gvp staff biodata'

    name = fields.Char(string="Name")
    designation = fields.Char(string="Designation")
    email = fields.Char(string="Email")
    pcontact = fields.Char(string="PContact")
    ocontact = fields.Char(string="OContact")
    profile_photo = fields.Binary(string="Profile Photo")
    dept_ids = fields.Many2one('gvp.department','department_id')


  
class department(models.Model):
    _name ='gvp.department'
    _description ='gvp department'

    dept_name = fields.Char(string="Department Name")
    department_id = fields.Many2one('gvp.biodata',string="Dept name")

