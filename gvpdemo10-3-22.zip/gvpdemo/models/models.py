# -*- coding: utf-8 -*-

from odoo import models, fields, api


class biodata(models.Model):
    _name = 'gvp.biodata'
    _description = 'gvp staff biodata'

    name = fields.Char(string="Name")
    designation = fields.Char(string="Designation")
    email = fields.Char(string="Email")
    pcontact = fields.Char(string="PContact")
    ocontact = fields.Char(string="OContact")
    profile_photo = fields.Binary(string="Profile Photo")


  
