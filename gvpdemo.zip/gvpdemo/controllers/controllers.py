from odoo import http

 

class gvpdata(http.Controller):

     @http.route('/home',type="http", auth='public',website=True)
     def home_page(self, **kwargs):
         return http.request.render('gvpdemo.home')
         
     # ***************About us***************

     @http.route('/about/history1',type="http", auth='public',website=True)
     def hostory1_page(self, **kwargs):
         return http.request.render('gvpdemo.history1')


     @http.route('/about/establishment',type="http", auth='public',website=True)
     def establishment_page(self, **kwargs):
         return http.request.render('gvpdemo.establishment')
         
        
     @http.route('/about/values1',type="http", auth='public',website=True)
     def values1_page(self, **kwargs):
         return http.request.render('gvpdemo.values1')
         

     @http.route('/about/emblem',type="http", auth='public',website=True)
     def emblem_page(self, **kwargs):
         return http.request.render('gvpdemo.emblem')

     @http.route('/about/song',type="http", auth='public',website=True)
     def song_page(self, **kwargs):
         return http.request.render('gvpdemo.song')
         
    
     @http.route('/about/salientsfeatures',type="http", auth='public',website=True)
     def salients_page(self, **kwargs):
         return http.request.render('gvpdemo.salientsfeatures')
         
     @http.route('/about/objective2',type="http", auth='public',website=True)
     def objective2_page(self, **kwargs):
         return http.request.render('gvpdemo.objective2')

     @http.route('/about/mission',type="http", auth='public',website=True)
     def mission_page(self, **kwargs):
         return http.request.render('gvpdemo.mission')

     @http.route('/about/gvpact',type="http", auth='public',website=True)
     def gvpact_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpact')

     @http.route('/about/uniqueness',type="http", auth='public',website=True)
     def uniqueness_page(self, **kwargs):
         return http.request.render('gvpdemo.uniqueness')

     @http.route('/about/vision',type="http", auth='public',website=True)
     def vision_page(self, **kwargs):
         return http.request.render('gvpdemo.vision')

     @http.route('/about/structgvp',type="http", auth='public',website=True)
     def structgvp_page(self, **kwargs):
         return http.request.render('gvpdemo.structgvp')



        #*************Administration*********************

     @http.route('/administration/chancellors',type="http", auth='public',website=True)
     def chancellor_page(self, **kwargs):
         return http.request.render('gvpdemo.chancellors')

     @http.route('/administration/vicechancellors',type="http", auth='public',website=True)
     def vicechancellor_page(self, **kwargs):
         return http.request.render('gvpdemo.vicechancellors')

     @http.route('/administration/registrar',type="http", auth='public',website=True)
     def registrar_page(self, **kwargs):
         return http.request.render('gvpdemo.registrar')

     @http.route('/administration/gvpmandal',type="http", auth='public',website=True)
     def gvpmandal_page(self, **kwargs):
         return http.request.render('gvpdemo.gvpmandal')

    #*****************Academics***************************

     @http.route('/academics/language',type="http", auth='public',website=True)
     def language_page(self, **kwargs):
         return http.request.render('gvpdemo.language')


     @http.route('/academics/social1',type="http", auth='public',website=True)
     def social_page(self, **kwargs):
         return http.request.render('gvpdemo.social1')

     @http.route('/academics/education',type="http", auth='public',website=True)
     def education_page(self, **kwargs):
         return http.request.render('gvpdemo.education')

     @http.route('/academics/managment',type="http", auth='public',website=True)
     def managment_page(self, **kwargs):
         return http.request.render('gvpdemo.managment')

     @http.route('/academics/hindi',type="http", auth='public',website=True)
     def hindi_page(self, **kwargs):
         return http.request.render('gvpdemo.hindi')


     @http.route('/academics/english',type="http", auth='public',website=True)
     def english_page(self, **kwargs):
         return http.request.render('gvpdemo.english')

     @http.route('/academics/anthropology',type="http", auth='public',website=True)
     def anthropology_page(self, **kwargs):
         return http.request.render('gvpdemo.anthropology')

     @http.route('/academics/rural',type="http", auth='public',website=True)
     def rural_page(self, **kwargs):
         return http.request.render('gvpdemo.rural')

     @http.route('/academics/IASE1',type="http", auth='public',website=True)
     def IASE1_page(self, **kwargs):
         return http.request.render('gvpdemo.IASE1')

     @http.route('/academics/biology',type="http", auth='public',website=True)
     def biology_page(self, **kwargs):
         return http.request.render('gvpdemo.biology')

     @http.route('/academics/hscience',type="http", auth='public',website=True)
     def hscience_page(self, **kwargs):
         return http.request.render('gvpdemo.hscience')

     @http.route('/academics/gandhian',type="http", auth='public',website=True)
     def gandhian_page(self, **kwargs):
         return http.request.render('gvpdemo.gandhian')

     @http.route('/academics/swork',type="http", auth='public',website=True)
     def swork_page(self, **kwargs):
         return http.request.render('gvpdemo.swork')

     @http.route('/academics/jsm',type="http", auth='public',website=True)
     def jsm_page(self, **kwargs):
         return http.request.render('gvpdemo.jsm')

     @http.route('/academics/peducation',type="http", auth='public',website=True)
     def peducation_page(self, **kwargs):
         return http.request.render('gvpdemo.peducation')

     @http.route('/academics/computer',type="http", auth='public',website=True)
     def computer_page(self, **kwargs):
         return http.request.render('gvpdemo.computer')

     @http.route('/academics/ruralm',type="http", auth='public',website=True)
     def ruralm_page(self, **kwargs):
         return http.request.render('gvpdemo.ruralm')

     @http.route('/deptgujarati',type="http", auth='public',website=True)
     def deptgujarati_page(self, **kwargs):
         return http.request.render('gvpdemo.deptgujarati')

     @http.route('/coprogram',type="http", auth='public',website=True)
     def coprogram_page(self, **kwargs):
         return http.request.render('gvpdemo.coprogram')

     @http.route('/program',type="http", auth='public',website=True)
     def program_page(self, **kwargs):
         return http.request.render('gvpdemo.program')

     @http.route('/cfac',type="http", auth='public',website=True)
     def cfac_page(self, **kwargs):
         return http.request.render('gvpdemo.cfac')

     @http.route('/cfaculty',type="http", auth='public',website=True)
     def cfaculty_page(self, **kwargs):
         return http.request.render('gvpdemo.cfaculty')



    #*****************Centres***************************

     @http.route('/centres/bhartiya',type="http", auth='public',website=True)
     def bhartiya_page(self, **kwargs):
         return http.request.render('gvpdemo.bhartiya')

     @http.route('/centres/hindibhasha',type="http", auth='public',website=True)
     def hindibhasha_page(self, **kwargs):
         return http.request.render('gvpdemo.hindibhasha')


    #*****************Facilities***************************

     @http.route('/facilities/arogya',type="http", auth='public',website=True)
     def arogya_page(self, **kwargs):
         return http.request.render('gvpdemo.arogya')

     @http.route('/facilities/library',type="http", auth='public',website=True)
     def library_page(self, **kwargs):
         return http.request.render('gvpdemo.library')

     @http.route('/facilities/sports',type="http", auth='public',website=True)
     def sports_page(self, **kwargs):
         return http.request.render('gvpdemo.sports')

     @http.route('/facilities/hostel',type="http", auth='public',website=True)
     def hostel_page(self, **kwargs):
         return http.request.render('gvpdemo.hostel')

     @http.route('/auditorium',type="http", auth='public',website=True)
     def audotorium_page(self, **kwargs):
         return http.request.render('gvpdemo.auditorium')

    #***************sub menu***************

     @http.route('/subm',type="http", auth='public',website=True)
     def sub_page(self, **kwargs):
         return http.request.render('gvpdemo.subm')

     @http.route('/submab',type="http", auth='public',website=True)
     def subab_page(self, **kwargs):
         return http.request.render('gvpdemo.submab')

     @http.route('/submadd',type="http", auth='public',website=True)
     def subadd_page(self, **kwargs):
         return http.request.render('gvpdemo.submadd')

     @http.route('/submlang',type="http", auth='public',website=True)
     def submlang_page(self, **kwargs):
         return http.request.render('gvpdemo.submlang')

     @http.route('/submsocial',type="http", auth='public',website=True)
     def submsocial_page(self, **kwargs):
         return http.request.render('gvpdemo.submsocial')

     @http.route('/submmanag',type="http", auth='public',website=True)
     def submmanag_page(self, **kwargs):
         return http.request.render('gvpdemo.submmanag')

     @http.route('/submdhindi',type="http", auth='public',website=True)
     def submdhindi_page(self, **kwargs):
         return http.request.render('gvpdemo.submdhindi')

     @http.route('/submdcomp',type="http", auth='public',website=True)
     def submdcomp_page(self, **kwargs):
         return http.request.render('gvpdemo.submdcomp')

     @http.route('/submdeng',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         return http.request.render('gvpdemo.submdeng')

     @http.route('/submcentres',type="http", auth='public',website=True)
     def submcentres_page(self, **kwargs):
         return http.request.render('gvpdemo.submcentres')

     @http.route('/submfac',type="http", auth='public',website=True)
     def submfac_page(self, **kwargs):
         return http.request.render('gvpdemo.submfac')


     @http.route('/estab',type="http", auth='public',website=True)
     def submdeng_page(self, **kwargs):
         return http.request.render('gvpdemo.estab')











